#ifndef PNTSTSH
#define PNTSTSH 1


#define MAXBLOCKS 10000

typedef point site;
typedef Coord* normalp;
point	site_blocks[MAXBLOCKS];
int	num_blocks;

