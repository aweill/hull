
#ifndef PNTSH
#define PNTSH 1


typedef double Coord;
typedef Coord* point;
extern int	pdim;	/* point dimension */

#endif
